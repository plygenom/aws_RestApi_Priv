// Create a DocumentClient that represents the query to get an item
const dynamodb = require('aws-sdk/clients/dynamodb');
const Logger = require('/opt/nodejs/log-helper');

const docClient = new dynamodb.DocumentClient();

// Get the environment variables
const tableName = process.env.TABLE_NAME;
var logger = new Logger(process.env.LOGGROUP_NAME);

exports.handler = async (event, context) => {

    const logStreamName = context.functionName + "-" + context.logStreamName;
    await logger.createLogStream(logStreamName);
  
    await logger.writeLog("Event inside function--> " + JSON.stringify(event));

    var resp = "";
    var body = event.body;
    body = JSON.parse(body);

    const doesItemExist = await checkIfRecordExists(body);
    
    if(doesItemExist)
        resp = await updateRecord(body);
    else
        resp = await putRecord(body);
    
    const response = {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Origin" : "*" // Required for CORS support to work
        },
        body: resp,
    };
    return response;
};

async function checkIfRecordExists(body){

    await logger.writeLog("Inside checkIfRecordExists");
    
    const { UserId, Department} = body;
    
    var params = {
        TableName:tableName,
        KeyConditionExpression:"UserId = :UserId and Department = :Department",
        ExpressionAttributeValues: {
            ":UserId":UserId,
            ":Department":Department
        },
        Select:"COUNT"
    };
    const resp = await docClient.query(params).promise();
    
    const { Count } = resp;
    
    if (Count == 1)
        return true;
    else
        return false;
}

async function putRecord(body){

    await logger.writeLog("Inside putRecord");
        
    const params = {
        TableName: tableName  ,
        Item: body
    };
    await docClient.put(params).promise();
    return "Item insert successful!";
}

async function updateRecord(body){
    
    await logger.writeLog("Inside updateRecord");

    const { UserId, Department, UserName} = body;
    
    const params = {
        TableName: tableName  ,
        Key:{
            "UserId": UserId,
            "Department": Department
        },
        UpdateExpression: "set UserName = :UserName",
        ExpressionAttributeValues:{
            ":UserName": UserName
        },
        ReturnValues:"UPDATED_NEW"
    };
    
    await docClient.update(params).promise();
    return "Item update successful!";
}
