const AWS = require('aws-sdk');

const cloudwatchlogs = new AWS.CloudWatchLogs();

module.exports = class Logger{
    constructor(logGroupName){
        this.isStreamCreated = false;
        this.logGroupName = logGroupName;
        this.sequenceToken = null;
    }

    async createLogStream(logStreamName){
        if(!this.isStreamCreated){
            console.log("inside if create log stream");
            //create the stream
            var params = {
              logGroupName: this.logGroupName,
              logStreamName: logStreamName
            };
            console.log("log params:: "+ JSON.stringify(params));
            await cloudwatchlogs.createLogStream(params).promise();
            this.isStreamCreated = true;
            this.logStreamName = logStreamName;
        }
    }

    async writeLog(message){
        var params = {
            logEvents: [ 
              {
                message: message,
                timestamp: Date.now()
              },
            ],
            logGroupName: this.logGroupName,
            logStreamName: this.logStreamName,
            sequenceToken: this.sequenceToken
          };
          const resp = await cloudwatchlogs.putLogEvents(params).promise();
          console.log(JSON.stringify(resp));
          this.sequenceToken = resp.nextSequenceToken;
    }

};