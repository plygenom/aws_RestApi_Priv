// Create a DocumentClient that represents the query to get an item
const dynamodb = require('aws-sdk/clients/dynamodb');
const Logger = require('/opt/nodejs/log-helper');

const docClient = new dynamodb.DocumentClient();

// Get the environment variables
const tableName = process.env.TABLE_NAME;
var logger = new Logger(process.env.LOGGROUP_NAME);

exports.handler = async (event, context) => {

    const logStreamName = context.functionName + "-" + context.logStreamName;
    await logger.createLogStream(logStreamName);
  
    await logger.writeLog("Event inside function--> " + JSON.stringify(event));
    
    // var { UserId } = event.queryStringParameters; 
       var { UserId } = event.params.querystring;  

    const params = {
      IndexName: "Id_GSI",
      KeyConditionExpression: "UserId = :UserId",
      ProjectionExpression: "Department",
      ExpressionAttributeValues: {
        ":UserId":UserId
      },
      TableName: tableName
    };
    
    const { Items } = await docClient.query(params).promise();
    
    const response = {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin" : "*" // Required for CORS support to work
        },
        //body:JSON.stringify(Items),
          body:Items,
    };
    return response;
};